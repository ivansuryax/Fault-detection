# Using Machine Learning Algorithm Classification to predict machine status

Algorithms used:

1. K Nearest Neighbors
2. Suppor Vector Machine
3. Logistic Regression
